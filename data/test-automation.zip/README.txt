/******************************************************************************/
 README

 In this archive, you will find the JavaScript and PHP files to automate
 password checking against 1Password (Firefox extension), 12306.cn (China
 railway ticket reservation system), Apple, Dropbox, Drupal, eBay, FedEx,
 Gmail, Intel, LastPass, Microsoft (v1, v2, v3), PayPal, Tencent QQ, Skype,
 Twitter and Yahoo!


 Client-side checkers:

 The client-side checkers are purely JavaScript based in the user browser.
 The checker present on the page at the time of the study is included in this
 archive. It is possible that the algorithm has now changed.
 Tests have been performed between June-July 2013 for Apple, Dropbox, Drupal,
 eBay, FedEx, Gmail, Microsoft (v1, v2, v3), PayPal, Skype, Twitter and Yahoo!
 They have been performed in March 2014 for 1Password, 12306.cn, Intel,
 LastPass and Tencent QQ.
 For example, Yahoo! do not use a password strength meter anymore on its
 website.
 
 Usage: open <service>.htm, load a dictionary, and hit Brute-force.


 Hybrid checkers:

 The hybrid checkers also have a JavaScript part which is included here and may
 be out-of-date.

 Usage:
  1. Run php <service>.php
  2. Open <service>.htm, load a dictionary, and hit Brute-force.


 Server-side checkers:

 The server-side checkers (and server part of hybrid checkers) are being queried
 by the PHP scripts. URLs for password ranking may also change.

 Usage: run php <service>.php <dictionary> <output-file>

/******************************************************************************/