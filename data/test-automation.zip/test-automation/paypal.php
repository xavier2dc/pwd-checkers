<?php
  require dirname(__FILE__) . DIRECTORY_SEPARATOR . "php" . DIRECTORY_SEPARATOR . "socket.class.php";
  require dirname(__FILE__) . DIRECTORY_SEPARATOR . "php" . DIRECTORY_SEPARATOR . "curlclient.class.php";
  require dirname(__FILE__) . DIRECTORY_SEPARATOR . "php" . DIRECTORY_SEPARATOR . "cache.class.php";

  $server = new Socket(81);
  $curlclient = new CurlClient("https://www.paypal.com/ca/cgi-bin/webscr?cmd=_forbidden-check&v=1",
                               "UTF-8");
  $cache = new Cache("./paypal.cache.txt");

  require dirname(__FILE__) . DIRECTORY_SEPARATOR . "php" . DIRECTORY_SEPARATOR . "proxy.inc.php";
?>