/* Evaluate the strength of a user's password.
 *
 * Returns the estimated strength and the relevant output message.
 */
var translate = [];
translate.weak = "Weak";
translate.fair = "Fair";
translate.good = "Good";
translate.strong = "Strong";

var Drupal = [];
    Drupal.evaluatePasswordStrength = function(password) {
        var weaknesses = 0, strength = 100, msg = [];
        
        var hasLowercase = /[a-z]+/.test(password);
        var hasUppercase = /[A-Z]+/.test(password);
        var hasNumbers = /[0-9]+/.test(password);
        var hasPunctuation = /[^a-zA-Z0-9]+/.test(password);

        // If there is a username edit box on the page, compare password to that, otherwise
        // use value from the database.
        //var usernameBox = $('input.username');
        var username = "";//(usernameBox.length > 0) ? usernameBox.val() : translate.username;

        // Lose 5 points for every character less than 6, plus a 30 point penalty.
        if (password.length < 6) {
            msg.push(translate.tooShort);
            strength -= ((6 - password.length) * 5) + 30;
        }

        // Count weaknesses.
        if (!hasLowercase) {
            msg.push(translate.addLowerCase);
            weaknesses++;
        }
        if (!hasUppercase) {
            msg.push(translate.addUpperCase);
            weaknesses++;
        }
        if (!hasNumbers) {
            msg.push(translate.addNumbers);
            weaknesses++;
        }
        if (!hasPunctuation) {
            msg.push(translate.addPunctuation);
            weaknesses++;
        }

        // Apply penalty for each weakness (balanced against length penalty).
        switch (weaknesses) {
            case 1:
                strength -= 12.5;
                break;
            
            case 2:
                strength -= 25;
                break;
            
            case 3:
                strength -= 40;
                break;
            
            case 4:
                strength -= 40;
                break;
        }

        // Check if password is the same as the username.
        //if (password !== '' && password.toLowerCase() === username.toLowerCase()) {
        //    msg.push(translate.sameAsUsername);
        //    // Passwords the same as username are always very weak.
        //    strength = 5;
        //}

        // Based on the strength, work out what text should be shown by the password strength meter.
        if (strength < 60) {
            indicatorText = translate.weak;
        } else if (strength < 70) {
            indicatorText = translate.fair;
        } else if (strength < 80) {
            indicatorText = translate.good;
        } else if (strength <= 100) {
            indicatorText = translate.strong;
        }

        // Assemble the final message.
        //msg = translate.hasWeaknesses + '<ul><li>' + msg.join('</li><li>') + '</li></ul>';
        //return {strength: strength,message: msg,indicatorText: indicatorText};
        return indicatorText;
    
    }
