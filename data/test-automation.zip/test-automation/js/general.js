/* read content from file */
function readFile() {
  var pathInput = document.getElementById('fileinput');
  var file = pathInput.files[0]; 
  if (file) {
    var r = new FileReader();
    r.onload = function(e) { 
      window.contents = e.target.result;
      alert( "Got the file.n" 
        +"name: " + file.name + "\n"
        +"type: " + file.type + "\n"
        +"size: " + file.size + " bytes\n"
        + "starts with: " + window.contents.substr(0, window.contents.indexOf("\n"))
      );  
    }
    r.readAsText(file);
    document.getElementById('loaded').innerHTML="<b>"+file.name+" loaded</b>";
  } else { 
    alert("Failed to load file");
  }
}

/* iterate through all the password list and record strength to write on file */
function bf(algo) {
  var bb = new BlobBuilder();
  var password;
  
  var outputname = document.getElementById("name").value;

  var currentPos = 0; // current descriptor position in file

  while (currentPos < window.contents.length) {
    // get next password from list
    password = window.contents.substr(
      currentPos,
      window.contents.indexOf("\n", currentPos) - currentPos );
    // update current position in the file
    currentPos += password.length+1;
    // trim extra spaces
    password = password.trim();

    // skip JtR comments
    //if (password.substr(0, 9) == "#!comment") continue;

    // compute strength
    strgth = tryPs(password);

    // write result to file
    bb.append(password+"\t"+strgth+"\r\n");
  }
  // propose to save file
  var fileSaver = saveAs(bb.getBlob(), service+"-"+outputname+".txt");
}
