var PAYPAL = {};
PAYPAL.widget = {};
PAYPAL.widget.PasswordMeter = {
    capsLockEnabled: null,
    result: '',
    tmp_result: '',
    blacklist: false,
    isAjax: true,
    keyC: 67,
    keyV: 86,
    keyX: 88,
    isCtrlkey: null,
    keyflag: null,
    myKeyCode: 0,
    CTRLKEY: 17,
    rightClickKey: 93,
    weak: false,
    isRetypefld: 0,
    matchFlag: '',
    timeOut: null,
    txt_pwd_msg: '',
    meterMessages: {
        'txt_msg_weak': 'txtWeak',
        'msg_strong': 'Strong',
        'msg_fair': 'Fair',
        'msg_weak': 'Weak',
        'msg_txtStrong': 'txt_StrongTip',
        'msg_txtWeak': 'txt_WeakTip',
        'msg_txtFair': 'txt_FairTip',
        'errorMsg': 'redAlertmsg',
        'MaxLmtErrmsg': 'maxLimitErr',
        'pwdErrmsg': 'pwdErr',
        'capsLockErrmsg': 'capsLockErr',
        'copyErrmsg': 'copyErr',
        'defaultMsg': 'pwdTips'
    },
    config: {
        passwd: {},
        countryCodePsc: "US",
        countryCode: 'en_US',
        min_len: 8,
        max_len: 20,
        keySeq: "qwertyuiopoiuytrewq~asdfghjklkjhgfdsa~zxcvbnmnbvcxz"
    },
    checkPass: function (strPasswd) {
        this.len = false;
        this.email = false;
        this.repeat = false;
        this.order = false;
        this.letterupper = false;
        this.letterlower = false;
        this.numbers = false;
        this.specials = false;
        this.order = false;
        this.strength = 0;
        //var strPasswd = YAHOO.lang.trim(this.config.passwd.value);
        this.config.passwd.value = strPasswd;
        this.config.passwd.type = "password";
        if (strPasswd.length > 0) {
            this.len = this.test_len(strPasswd);
            var email = this.config.email;
            if (email && email.value) {
                this.email = this.test_email(strPasswd, email.value);
            }
            this.repeat = this.test_repeatchar(strPasswd);
            this.order = this.test_order(strPasswd);
            this.letterlower = this.test_lower(strPasswd);
            this.letterupper = this.test_upper(strPasswd);
            this.numbers = this.test_numbers(strPasswd);
            this.specials = this.test_special(strPasswd);
            if (this.letterlower && this.letterupper) {
                this.strength++;
                if (this.numbers) {
                    this.strength++;
                }
                if (this.specials) {
                    this.strength++;
                }
            } else {
                if (this.letterlower) {
                    this.strength++;
                }
                if (this.letterupper) {
                    this.strength++;
                }
            }
            if (this.numbers) {
                this.strength++;
            }
            if (this.specials) {
                this.strength++;
            }
            this.getResult();
        }
        return this.result;
    },
    getResult: function () {
        var result = 'lame';
        if (this.weak) {
            var result = 'weak';
        }
        this.weak = (this.email || this.repeat || this.order);
        if (this.len) {
            result = 'lame';
            this.result = result;
        } else if (this.weak || this.strength < 2) {
            result = 'weak';
            this.result = result;
        } else if ((!this.weak && this.strength < 3) || (!this.weak && this.strength > 2)) {
            var strPasswd = this.config.passwd.value.trim();
            if ((strPasswd.length >= 8)) {
                this.test_blacklist(strPasswd, null);
                
            }
        }
    },
    blacklist_result: function (ajaxval, e_emailFld) {
        var result = "lame";
        if (this.weak) {
            var result = 'weak';
        }
        if (ajaxval.trim() == "true") {
            result = 'weak';
        } else if (!this.weak && this.strength < 3) {
            result = 'fair';
        } else if (!this.weak && this.strength > 2) {
            result = 'strong';
        }
        this.result = result;
        this.tmp_result = this.result;
        this.isAjax = false;
        if (this.config.passwd.value == '') {
            this.result = 'lame';
        }
        if (e_emailFld == 'email' && this.email == true) {
            //this.showResult(this.result);
        } else if (e_emailFld == 'email' && this.email == false) {
            //this.hidemeter();
        } else {
            //this.showResult(this.result);
        }
    },
    maxlimit: function () {
        var strPwd = this.config.passwd.value.trim();
        var strrePwd = strPwd;
        //this.matchpassword(strPwd, strrePwd);
        //clearTimeout(PAYPAL.widget.PasswordMeter.timeOut);
        if ((strPwd.length >= this.config.max_len) && (((strrePwd == '') && this.isRetypefld == 0) || ((strrePwd.length <= this.config.max_len) && this.isRetypefld == 0) || ((strrePwd.length >= this.config.max_len) && this.matchFlag == 0 && this.myKeyCode != this.rightClickKey && this.keyflag == 0))) {

            //this.showerrmsg(maxLimitErr);
            //PAYPAL.widget.PasswordMeter.timeOut = setTimeout(function () {
            //    PAYPAL.widget.PasswordMeter.replace_warningmsg(strPwd, strrePwd);
            //}, 4000);
            return true;
        } else if ((strPwd == '') && (strrePwd.length >= this.config.max_len) && (this.isRetypefld == 1)) {
alert(strPwd);
            //this.showerrmsg(maxLimitErr);
            //PAYPAL.widget.PasswordMeter.timeOut = setTimeout(function () {
            //    PAYPAL.widget.PasswordMeter.replace_passwordhelp(strPwd, strrePwd);
            //}, 4000);
            return true;
        }
        return false;
    },
    matchpassword: function (strPwd, strrePwd) {
        /*if ((strPwd && strrePwd) != '') {
            if (strPwd != strrePwd) {
                var a = strPwd.split("");
                var b = strrePwd.split("");
                var blen = b.length;
                for (var i = 0; i < blen; i++) {
                    this.matchFlag = 0;
                    if (a[i] != b[i]) {
                        this.matchFlag = 1;
                        if (YUD.get('fstatusChk')) {
                            if (YUD.get('fstatusChk').checked == true) {
                                this.toggleSubmit(true);
                            }
                        } else {
                            this.toggleSubmit(true);
                        }
                        this.showerrmsg(pwdErr);
                    }
                    if (this.matchFlag == 1 && strrePwd != '') {
                        var k = 1;
                    }
                }
                if (k == 1) {
                    if (this.config.mtrUpward) {
                        YUD.addClass(this.config.passwd, "pswd_bg");
                        YUD.addClass(this.config.retype, "pswd_bg");
                    }
                }
            } else {
                if (this.result == 'lame' && this.config.passwd.value.length <= this.config.min_len) {
                    if (YUD.get('fstatusChk')) {
                        if (YUD.get('fstatusChk').checked == true) {
                            this.toggleSubmit(true);
                        }
                    } else {
                        this.toggleSubmit(true);
                    }
                }
                if (this.result != 'weak') {
                    this.removeclass(this.config.passwd, "pswd_bg");
                    this.removeclass(this.config.retype, "pswd_bg");
                } else if (this.result == 'weak' && strPwd == strrePwd) {
                    this.removeclass(this.config.retype, "pswd_bg");
                }
            }
        } else if (strrePwd == '') {
            this.removeclass(this.config.retype, "pswd_bg");
        }*/
    },
    showerrmsg: function (currentErrMsg) {
        var pwdH = this.config.pwdH;
        pwdH.innerHTML = currentErrMsg;
        this.replceclass(pwdH, "hide", "show");
        this.replceclass(this.config.cont, "show", "hide");
        this.replceclass(pwdH, "gray", "red");
    },
    test_capson: function (e) {
        var keycode = YUE.getCharCode(e);
        if ((keycode >= 65 && keycode <= 90) && !e.shiftKey) {
            this.capsLockEnabled = true;
        }
        this.test_retypeFld(e);
    },
    test_capsonres: function (e) {
        var strPwd = this.config.passwd.value.trim();
        var strrePwd = strPwd;
        var CAPSKEY = 20;
        var tar = YUE.getTarget(e);
        if ((e.keyCode == CAPSKEY) && (this.capsLockEnabled !== null)) {
            this.capsLockEnabled = !this.capsLockEnabled;
        }
        if (this.capsLockEnabled == true) {
            if (this.config.mtrUpward) {
                if (strPwd.length < 8 && strPwd != '') {
                    this.showerrmsg(capsLockErr);
                } else if (strrePwd.length < 8 && strrePwd != '') {
                    this.showerrmsg(capsLockErr);
                }
            }
            if (strPwd.length < this.config.min_len && strPwd != '') {
                this.showerrmsg(capsLockErr);
            }
            if (strrePwd.length < this.config.min_len && strrePwd != '' && tar.id == this.config.retype.id) {
                this.showerrmsg(capsLockErr);
            }
            //this.maxlimit();
        }
    },
    test_len: function (str) {
        if (str.length < (this.config.min_len)) {
            //this.hidemeter();
            return true;
        } else if (str.length > (this.config.max_len)) {
            return true;
            //maxlimit
        }
        return false;
    },
    test_blacklist: function (str, e_emailFld) {
        this.blacklist_result(checkBlackList(str), this.argument_email);
        /*var url = "http://localhost/checker"; //"webscr?cmd=_forbidden-check&v=1";
        PAYPAL.util.Connect.send(url, {
                method: "post",
                callback: PAYPAL.widget.PasswordMeter.ajaxblacklistchk,
                scope: this,
                argument_email: e_emailFld,
                query: "search_str=" + str
            });*/
    },
    test_email: function (str, email) {
        if (email.indexOf('@') > -1) {
            var arr = email.split('@');
            var username = arr[0].toLowerCase();
            if (username.length == 0) {
                return false;
            }
            var domainname = arr[1];
            if ((username.indexOf(str.toLowerCase()) > -1) || (str.toLowerCase().indexOf(username) > -1)) {
                return true;
            }
        }
        return false;
    },
    test_upper: function (str) {
        if (str.match(/[A-Z].*/)) {
            return true;
        }
        return false;
    },
    test_lower: function (str) {
        if (str.match(/[a-z].*/)) {
            return true;
        }
        return false;
    },
    test_numbers: function (str) {
        if (str.match(/\d+/)) {
            return true;
        }
        return false;
    },
    test_special: function (str) {
        if (str.match(/[~,!,@,#,$,%,^,&,*,(,),+,=]/)) {
            return true;
        }
        return false;
    },
    test_repeatchar: function (str) {
        str_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789~!@#\$%&*\(\)\+=\^';
        if (this.config.countryCodePsc.value == 'DE') {
            str_chars = str_chars.concat(this.config.deKey);
        }
        for (i = 0, k = str_chars.length; i < k; i++) {
            var char = str_chars.substr(i, 1);
            cmd = '/["' + char + '"]+/g';
            cmd = eval(cmd);
            var matches = str.match(cmd);
            if (matches) {
                for (j = 0, r = matches.length; j < r; j++) {
                    newstr = new String(matches[j]);
                    if (newstr.length > 3) {
                        return true;
                    }
                }
            }
        }
        return false;
    },
    test_order: function (str) {
        str_chars = '012345678909876543210';
        if (this.inSeq(str, str_chars)) return true;
        if (this.config.countryCodePsc.value == 'DE') {
            str_chars = this.config.deKey;
            if (this.inSeq(str, str_chars)) {
                return true;
            }
        }
        str_chars = this.config.keySeq;
        if (str_chars.indexOf('~') > -1) {
            var arr = str_chars.split('~');
            var row1 = arr[0],
                row2 = arr[1],
                row3 = arr[2];
            if ((this.inSeq(str, row1)) || (this.inSeq(str, row2)) || (this.inSeq(str, row3))) {
                return true;
            }
            return false;
        }
    },
    inSeq: function (str, str_chars) {
        for (i = 0, j = str_chars.length; i < j; i++) {
            var nc = str_chars.substr(i + 1, 3);
            if (nc.length == 3) {
                cmd = '/' + str_chars.substr(i, 1) + '(?=' + nc + ')/i';
                cmd = eval(cmd);
                if (str.match(cmd)) {
                    return true;
                }
            }
        }
        return false;
    },
    password_tips: function (pwdstrength) {
        if (pwdstrength == 'weak') {
            helplink.appendChild(document.createTextNode(txt_WeakTip));
        } else if (pwdstrength == 'fair') {
            helplink.appendChild(document.createTextNode(txt_FairTip));
        } else if (pwdstrength == 'strong') {
            helplink.appendChild(document.createTextNode(txt_StrongTip));
        }
        inlinehelp.appendChild(helplink);
    },
    add_hiddenvar: function (fields) {
        var hiddenVar = document.createElement('input');
        hiddenVar.type = "hidden";
        hiddenVar.name = "js_enabled";
        hiddenVar.value = "true";
        var tmp = document.forms[fields.formName].appendChild(hiddenVar);
    },
    addclass: function (whichId, adclass) {
        if (YUD.hasClass(whichId, adclass)) {
            YUD.addClass(whichId, adclass);
        }
    },
    removeclass: function (whichId, rmvclass) {
        if (YUD.hasClass(whichId, rmvclass)) {
            YUD.removeClass(whichId, rmvclass);
        }
    },
    replceclass: function (whichId, chkclass, applycls) {

    },
    inarray: function (str, arr) {
        var inarr = false;
        for (i = arr.length - 1; i >= 0; i--) {
            if (str.toLowerCase().indexOf(arr[i].toLowerCase()) > -1) {
                return true;
            }
        }
        return inarr;
    },

};