var prop = new Array();
prop["passwordMinimumLength"] = 8;
prop["passwordStrengthTooShort"] = "too short";
prop["passwordStrengthStrong"] = "strong";
prop["passwordStrengthMedium"] = "moderate";
prop["passwordStrengthWeak"] = "weak";

function passwordStrengthCalculator(passwd) 
{
    var passwordScore = 0;
    var passwordStrength = "";

    // password length 6-7
    if (passwd.length > 5 && passwd.length < 8) 
    {
        passwordScore = (passwordScore + 6);
    } 
    // password length 8-15
    else if (passwd.length > 7 && passwd.length < 16) 
    {
        passwordScore = (passwordScore + 12);
    } 
    else if (passwd.length > 15)  // password length > 15
    {
        passwordScore = (passwordScore + 18);
    }

    // Character Check: lower and uppper character check
    if (passwd.match(/[a-z]/)) 
    {
        passwordScore = (passwordScore + 1);
    }
    
    if (passwd.match(/[A-Z]/)) 
    {
        passwordScore = (passwordScore + 5);
    }

    // Number Check
    if (passwd.match(/\d+/))  // at least one numeric
    {
        passwordScore = (passwordScore + 5);
    }
    
    if (passwd.match(/(.*[0-9].*[0-9].*[0-9])/))  // at least three numeric
    {
        passwordScore = (passwordScore + 5);
    }


    // Symbol Check
    if (passwd.match(/.[!,@,#,$,%,^,&,*,?,_,~]/))  // at least one special character
    {
        passwordScore = (passwordScore + 5);
    }

    // Symbol Check - 2
    if (passwd.match(/(.*[!,@,#,$,%,^,&,*,?,_,~].*[!,@,#,$,%,^,&,*,?,_,~])/)) 
    {
        passwordScore = (passwordScore + 5);
    }


    // Mix check: upper/lower case, alpha + numeric
    if (passwd.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/))  // check for both upper and lower case
    {
        passwordScore = (passwordScore + 2);
    }
    
    if (passwd.match(/([a-zA-Z])/) && passwd.match(/([0-9])/))  // check for both alpha and numeric
    {
        passwordScore = (passwordScore + 2);
    }

    // Mix check: alpha, numbers, and symbols
    if (passwd.match(/([a-zA-Z0-9].*[!,@,#,$,%,^,&,*,?,_,~])|([!,@,#,$,%,^,&,*,?,_,~].*[a-zA-Z0-9])/)) 
    {
        passwordScore = (passwordScore + 2);
    }
    
    if (passwd.length < 1) {
        passwordStrength = "";
    } else if (passwd.length < prop["passwordMinimumLength"]) {
        passwordStrength = prop["passwordStrengthTooShort"];
    } else {
        if (passwordScore < 25) 
        {
            passwordStrength = prop["passwordStrengthWeak"];
        } 
        else if (passwordScore > 24 && passwordScore < 35) 
        {
            passwordStrength = prop["passwordStrengthMedium"];
        /*passwordStrength = prop["passwordStrengthMedium"]*/
        } 
        else if (passwordScore > 34) 
        {
            passwordStrength = prop["passwordStrengthStrong"];
        /*passwordStrength = prop["passwordStrengthStrong"]*/
        }
    }
    return(passwordStrength);
}

function validate(pass) {
    var errorCode = "";

    //var charCode = (event.which) ? event.which : event.keyCode ;
    
    var passwd = pass;
    //var message = prop['confirmMessage');
    var accountname = "";// appleid;
    
    
    if (passwd.length < 8) {
        errorCode = "-20725";
        prop['password-eight-characters'] = 'fail';
    } 
    else {
        prop['password-eight-characters'] = 'pass';
    }
    
    
    if (passwd.length > 32) {
        errorCode = errorCode + "," + "-20726";
    }
    
    
    if (!passwd.match(/[a-z]/)) {
        errorCode = errorCode + "," + "-21103";
        prop['password-one-char'] = 'fail';
    } 
    else {
        prop['password-one-char'] = 'pass';
    }
    
    if (!passwd.match(/[A-Z]/)) {
        errorCode = errorCode + "," + "-21102";
        prop['password-one-capital'] = 'fail';
    } 
    else {
        prop['password-one-capital'] = 'pass';
    }
    
    if (!passwd.match(/\d+/)) {
        errorCode = errorCode + "," + "-20734";
        prop['password-one-number'] = 'fail';
    } 
    else {
        prop['password-one-number'] = 'pass';
    }
    
    if (passwd.match(/(.)\1\1/)) {
        errorCode = errorCode + "," + "-20736";
        prop['password-three-identical'] = 'fail';
    
    } 
    else {
        prop['password-three-identical'] = 'pass';
    }
    
    
    if (accountname == passwd) {
        errorCode = errorCode + "," + "-20733";
        prop['password-same-as-account'] = 'fail';
    } 
    else {
        prop['password-same-as-account'] = 'pass';
    }
    
    if (passwd.length == 0) {
        prop['password-eight-characters'] = '';
        prop['password-one-char'] = '';
        prop['password-one-capital'] = '';
        prop['password-one-number'] = '';
        prop['password-three-identical'] = '';
        prop['password-same-as-account'] = '';
    }
    
    if (errorCode.indexOf(",") == 0) {
        errorCode = errorCode.substring(1);
    }
    
    //prop['passworderror').value = errorCode;

}

function ValidateCommonPassword(pass) 
{   
    
    if (prop['password-one-char'] == 'pass' && prop['password-one-capital'] == 'pass' && prop['password-one-number'] == 'pass' && prop['password-three-identical'] == 'pass' && prop['password-same-as-account'] == 'pass' && prop['password-eight-characters'] == 'pass') 
    {
        
        callAjax(pass);
    
    } 
    else 
    {
        prop['newpasswordfield'] = 'fail';
        prop['password-dictionary-word'] = '';
    }

}

function callAjax(pass) 
{
    var xmlhttp;
    prop['newpasswordfield'] = 'requestinprocess';
    if (window.XMLHttpRequest) 
    {
        xmlhttp = new XMLHttpRequest();
    } 
    else 
    {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() 
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
        {
            if (xmlhttp.responseText == '-21104') 
            {
                prop['newpasswordfield'] = 'fail';
                prop['password-dictionary-word'] = 'fail';
            } 
            else {
                prop['newpasswordfield'] = 'pass';
                prop['password-dictionary-word'] = 'pass';
            }
        
        
        }
    }
    var url = '';
    if (document.URL.indexOf(".woa") != -1) 
    {
        url = document.URL.substring(0, document.URL.indexOf(".woa")) + ".woa/wa/validatePassword?";
    } 
    else 
    {
        url = "http://" + 'localhost' + "/cgi-bin/WebObjects/MyAppleId.woa/wa/validatePassword?";
    }
    xmlhttp.open("POST", url, false);
    var queryString = "pass=" + encodeURIComponent(pass);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    xmlhttp.send(queryString);
}


