var getPwdRank = function(a) {
        var b = 0;
        a.match(/[a-z]/g) && b++;
        a.match(/[A-Z]/g) && b++;
        a.match(/[0-9]/g) && b++;
        a.match(/[^a-zA-Z0-9]/g) && b++;
        b = b > 3 ? 3 : b;
        if (a.length < 6 || /^\d{1,8}$/.test(a))
            b = 0;
        a.length < 8 && b > 1 && (b = 1);
        return b
}
