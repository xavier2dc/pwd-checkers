getpasswordstrength = function (c, e) {
    var f = 0;
    if ("" == c && "" == e) return 0;
    if (e == c) return 1;
    "" != c && -1 != c.indexOf(e) && (f -= 15);
    "" != c && -1 != e.indexOf(c) && (f -= c.length);
    f += e.length;
    0 < e.length && 4 >= e.length ? f += e.length :
        5 <= e.length && 7 >= e.length ? f += 6 :
            8 <= e.length && 15 >= e.length ? f += 12 :
                16 <= e.length && (f += 18);
    e.match(/[a-z]/) && (f += 1);
    e.match(/[A-Z]/) && (f += 5);
    e.match(/\d/) && (f += 5);
    e.match(/.*\d.*\d.*\d/) && (f += 5);
    e.match(/[!,@,#,$,%,^,&,*,?,_,~]/) && (f += 5);
    e.match(/[!,@,#,$,%,^,&,*,?,_,~].*[!,@,#,$,%,^,&,*,?,_,~]/) && (f += 5);
    e.match(/(?=.*[a-z])(?=.*[A-Z])/) && (f += 2);
    e.match(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])/) && (f += 2);
    e.match(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!,@,#,$,%,^,&,*,?,_,~])/) && (f += 2);
    var d = [],
        g = 0,
        h, l;
    for (h = 0; h < e.length; ++h) l =
        e.charAt(h), "undefined" == typeof d[l] && (d[l] = 1, ++g);
    if (1 == g) return 2;
    f *= 2;
    0 > f ? f = 0 : 100 < f && (f = 100);
    return f
};