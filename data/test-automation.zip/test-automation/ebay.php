<?php
  require dirname(__FILE__) . DIRECTORY_SEPARATOR . "php" . DIRECTORY_SEPARATOR . "curlclient.class.php";
  //$curlclient = new CurlClient("https://scgi.ebay.ca/ws/ajax", "iso-8859-1");
  $curlclient = new CurlClient("https://reg.ebay.ca/reg/ajax", "UTF-8");

  if (count($argv) < 2) {
    die("Usage: {$argv[0]} dictionary [output-file]".PHP_EOL);
  }

  if (is_readable($argv[1])) {
    $passwords = file($argv[1]);
  } else {
    die("File '".$argv[1]."' unreadable.".PHP_EOL);
  }

  $output = null;
  if (isset($argv[2])) {
    if (is_file($argv[2])) {
      echo "File exists! Going to overwrite it in 3 seconds".PHP_EOL;
      sleep(3);
    }
    $output = fopen($argv[2], "w+");
  }

  /* check an array of passwords */
  function check($passwords) {
    GLOBAL $curlclient, $output;

    for ($i=0; $i<count($passwords); $i++) {

      // prepare data
      $pass = trim($passwords[$i]);

      // JtR comments
      // if (substr($pass,0,9)=="#!comment") continue;

      // execute the request and get back the result
      if (strlen($pass) < 6)
        $data = "Invalid";
      else {
        $json = $curlclient->send("PASSWORD=".urlencode($pass)."&mode=6");
        if ($json === false) {
          echo 'Error occured for "'.$pass.'": ' . curl_error($ch)."\r\n";
          $i--;
          continue;
        }

        $dec = json_decode($json, true);
        if ($dec != null) {
          $data = $dec["pwdMeter"];
        } else $data = "FAILED ".$json;
      }

      // print result
      //print_r( $data );

      $status = $data;

      echo $pass."\t".$status.PHP_EOL;
    }
  }

  check($passwords);
  
  $curlclient->close();
  
  if ($output != null) {
    fclose($output);
  }

?>
