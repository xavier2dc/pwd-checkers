<?php
  require dirname(__FILE__) . DIRECTORY_SEPARATOR . "php" . DIRECTORY_SEPARATOR . "socket.class.php";
  require dirname(__FILE__) . DIRECTORY_SEPARATOR . "php" . DIRECTORY_SEPARATOR . "curlclient.class.php";
  require dirname(__FILE__) . DIRECTORY_SEPARATOR . "php" . DIRECTORY_SEPARATOR . "cache.class.php";

  $server = new Socket(80);
  $curlclient = new CurlClient("https://appleid.apple.com/cgi-bin/WebObjects/MyAppleId.woa/wa/validatePassword?",
                               "UTF-8");
  $cache = new Cache("./apple.cache.txt");

  require dirname(__FILE__) . DIRECTORY_SEPARATOR . "php" . DIRECTORY_SEPARATOR . "proxy.inc.php";
?>